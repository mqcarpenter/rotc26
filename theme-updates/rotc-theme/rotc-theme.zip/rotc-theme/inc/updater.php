<?php
/**
 * inc/updater.php
 * Self-hosted theme updates, so pushing a new version of this theme
 * shows up as a normal "Update Available" in Appearance > Themes /
 * Dashboard > Updates -- a one-click Update, not re-uploading a zip
 * through Add New Theme every time.
 *
 * There's no WordPress.org listing for a private theme like this, so
 * WordPress core has nothing to poll on its own. The `Update URI`
 * header in style.css (WP 5.8+) is exactly the sanctioned way to tell
 * core "don't treat this as a wordpress.org theme, someone else is
 * managing its updates" -- but core still needs to be told WHERE to
 * look and WHAT to do with the answer, which is what this file does:
 * fetch a small JSON manifest from that same URI, compare its version
 * against what's installed, and inject a normal update entry into the
 * transient WordPress already checks on every admin page load.
 *
 * The manifest + the zip it points at live in manage/theme-updates/
 * rotc-theme/ (same git repo and deploy path as the rest of the
 * /manage/ app, just serving two static files -- no PHP execution
 * needed there). To release a new version:
 *   1. Bump the Version in style.css.
 *   2. Rebuild the zip (wp-content/themes -> zip -r rotc-theme.zip rotc-theme).
 *   3. Copy that zip to manage/theme-updates/rotc-theme/rotc-theme.zip,
 *      and update manage/theme-updates/rotc-theme/info.json's "version"
 *      (and "sections.changelog" if you want it to show).
 *   4. Commit + push (same as any other /manage/ change) and deploy.
 * WordPress checks this on its own schedule (roughly every 12 hours,
 * matching the transient TTL below) or immediately if an admin visits
 * Dashboard > Updates and clicks "Check Again".
 */

if (!defined('ABSPATH')) exit;

const ROTC_THEME_UPDATE_MANIFEST = 'https://www.returnofthechampions.com/manage/theme-updates/rotc-theme/info.json';
const ROTC_THEME_UPDATE_TRANSIENT = 'rotc_theme_update_manifest';

function rotc_theme_fetch_update_manifest(): ?array {
    $cached = get_transient(ROTC_THEME_UPDATE_TRANSIENT);
    if (is_array($cached)) return $cached;

    $response = wp_remote_get(ROTC_THEME_UPDATE_MANIFEST, ['timeout' => 8]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return null;

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($data) || empty($data['version']) || empty($data['download_url'])) return null;

    set_transient(ROTC_THEME_UPDATE_TRANSIENT, $data, 12 * HOUR_IN_SECONDS);
    return $data;
}

/**
 * Hooked on pre_set_site_transient_update_themes -- the same transient
 * WordPress core itself populates for wordpress.org themes, so this
 * theme's update rides along in the exact same UI (Appearance >
 * Themes shows the notice, Dashboard > Updates lists it, Bulk Update
 * on the Themes screen includes it).
 */
function rotc_theme_check_for_update($transient) {
    if (!is_object($transient)) $transient = new stdClass();
    if (!isset($transient->response) || !is_array($transient->response)) $transient->response = [];
    if (!isset($transient->checked) || !is_array($transient->checked)) $transient->checked = [];

    $slug = get_stylesheet(); // 'rotc-theme' -- the folder/text-domain name.
    $manifest = rotc_theme_fetch_update_manifest();
    if ($manifest === null) return $transient;

    $current = wp_get_theme($slug)->get('Version');
    if (version_compare($manifest['version'], (string) $current, '>')) {
        $transient->response[$slug] = [
            'theme'       => $slug,
            'new_version' => $manifest['version'],
            'url'         => $manifest['url'] ?? 'https://www.returnofthechampions.com/',
            'package'     => $manifest['download_url'],
        ];
    } else {
        // Already caught up -- don't let a stale entry from an earlier
        // check linger and claim an update is available when it isn't.
        unset($transient->response[$slug]);
    }
    return $transient;
}
add_filter('pre_set_site_transient_update_themes', 'rotc_theme_check_for_update');

/**
 * Fills in the "View version X.X details" popup on the Themes screen
 * with the manifest's changelog, so an update isn't a total mystery
 * before clicking Update.
 */
function rotc_theme_update_details($result, $action, $args) {
    if ($action !== 'theme_information' || empty($args->slug) || $args->slug !== get_stylesheet()) {
        return $result;
    }
    $manifest = rotc_theme_fetch_update_manifest();
    if ($manifest === null) return $result;

    return (object) [
        'name'          => wp_get_theme(get_stylesheet())->get('Name'),
        'slug'          => get_stylesheet(),
        'version'       => $manifest['version'],
        'sections'      => $manifest['sections'] ?? [],
        'download_link' => $manifest['download_url'],
    ];
}
add_filter('themes_api_result', 'rotc_theme_update_details', 10, 3);
